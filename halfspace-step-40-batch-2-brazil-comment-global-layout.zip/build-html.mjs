import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";

const root = path.resolve(process.argv[2] || ".");
const templatePath = path.join(root, "src", "index.template.html");
const requestedOutput = process.argv[3] || "index.html";
const outputPath = path.isAbsolute(requestedOutput)
  ? requestedOutput
  : path.join(root, requestedOutput);
let html = await readFile(templatePath, "utf8");
const includePattern = /<!-- @include ([a-z0-9./-]+\.html) -->\n?/g;
const includes = [...html.matchAll(includePattern)];

for (const match of includes) {
  const partial = await readFile(path.join(root, "src", match[1]), "utf8");
  html = html.replace(match[0], partial);
}

if (includePattern.test(html)) throw new Error("Unresolved HTML component include");
await writeFile(outputPath, html, "utf8");
console.log(`Assembled ${includes.length} components into ${path.basename(outputPath)}.`);
